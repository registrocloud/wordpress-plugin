<?php
/*
Plugin Name: Webpane WordPress (official plugin)
Plugin URI: https://github.com/webpane/webpane-wordpress-plugin
Description: Get a new banana for your split.
Author: webpane
Version: 0.0.1
Author URI: https://github.com/webpane
*/

require_once __DIR__ . '/vendor/autoload.php';

use Webpane\WordpressPlugin\Plugin;

$plugin = new Plugin();

$plugin->run();
