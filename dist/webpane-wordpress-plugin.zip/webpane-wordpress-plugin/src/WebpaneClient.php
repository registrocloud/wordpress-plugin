<?php
namespace Webpane\WordpressPlugin;

use GuzzleHttp\Client as GuzzleHttpClient;

class WebpaneClient extends GuzzleHttpClient
{

}
